<?php
// Bloomwire Campaign Manager - SMS Gateway
// Copyright © Bloomwire (Private) Ltd., All rights reserved.